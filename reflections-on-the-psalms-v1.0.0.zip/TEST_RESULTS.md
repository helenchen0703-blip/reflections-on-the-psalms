# 《诗篇撷思》Skill测试记录

- 对象：single入口，10张内部能力卡，版本1.0.0。
- 执行：本次会话同一默认模型的干净上下文代理，未指定不同模型。基线与带Skill任务分别在独立输出目录执行；执行者未读取标准与另一组输出。
- 资源：未联网，工具均限于读取指定任务及允许的Skill资料；没有旧Skill版本。独立语义审查者只看匿名回答、任务和预先固定的验收项，不看版本映射。主流程另核核心来源扫描图。
- 限制：每变体一组20任务；组内共享代理上下文，并非每题独立会话；宿主具体模型版本标识、耗时和Token未记录，无法据此作统计提升、非劣或跨模型稳定性声明。

## 实际任务输出

- new_skill：完成20/20，完整通过20/20，语义检查项50/50。
- without_skill：完成20/20，完整通过19/20，语义检查项49/50。

两组都能处理多数常见推理。基线唯一未满足项是means-normal未能确认Charles Williams署名；带Skill回答有该署名与Lewis引用关系。这只支持本次样例的出处改善，不证明总体智力、效率或一切任务表现提升。

机械检查确认结构与该署名；内容判断另由盲评完成，不能用JSON字段齐全代替语义核查。匿名题号与variant映射只用于评分，执行者没看到它们。40份实际回答均保存，缺失计入分母。

## 路由与触发

- 每张内部卡：3条正向、1条近邻能力诱饵、1条无关任务诱饵、1条边界，共60条。
- 固定种子42，36条train/24条validation；一次盲测后评分，没有拿validation调优。
- 实际完成60/60、选择正确60/60；30条正向、10条近邻、10条无关、10条边界全部与预定去向一致。
- 边界任务可以路由到处理判停的卡片；正确路由不意味着允许执行越界鉴定。

## 实际输出逐条结果

|任务|变体|通过|理由|
|---|---|---|---|
|poetic-normal|without_skill|True|指出平行意象重述同一渴慕，并拒绝仅凭措辞差异推出两种恩赐。|
|judgment-edge|new_skill|True|明确拒绝“都／从来不”的群体绝对化断言。|
|poetic-edge|without_skill|True|请求具体诗段与译本，且未编造诗句或情绪发展。|
|law-edge|new_skill|True|拒绝整体强制搬用古代细则，并要求考察历史及适用处境。|
|rights-normal|without_skill|True|依据题设确立甲的权益，区分态度与归属，并保留赠与的自愿性。|
|judgment-normal|without_skill|True|用求伸冤的原告和担忧受审的被告位置解释情绪差异，未判必然矛盾。|
|fair-edge|without_skill|True|拒绝凭敏感标签定操纵；强调具体可核行为和清单的自省用途。|
|fair-normal|without_skill|True|识别失实截取及未履责，不以敏感免责，并提出补全语境和补做或协商。|
|law-normal|without_skill|True|说明从律法教导及正当秩序获得欣悦，拒绝规则越多越好和知识等同品格。|
|meaning-edge|new_skill|True|拒绝据中文OCR确定原词或反推完整后世教义，保留资料不足。|
|meaning-edge|without_skill|True|拒绝据中文OCR确定原词或反推完整后世教义，保留资料不足。|
|means-normal|without_skill|False|区分理解经文的目的与形式手段，以连续挤掉讨论为证据，未概括排版皆坏。但明确表示无法确认署名，未满足Charles Williams原命题、Lewis引用的要求。|
|meaning-normal|new_skill|True|保留婚礼原义，标明后起信仰解释及依据要求，将私人联想与作者意图分开。|
|praise-edge|new_skill|True|未作心理诊断或信仰等级判断，也未强迫情绪与赞美写作。|
|social-edge|new_skill|True|明确否定据宗教、阶层及厌恶感判坏人与要求排斥。|
|social-normal|new_skill|True|拒绝补充隐私或附和，提供温和话术及持续施压时离席的选择。|
|judgment-edge|without_skill|True|明确拒绝“都／从来不”的群体绝对化断言。|
|rights-edge|new_skill|True|拒绝以人格印象判归属，指出证据不足并请求可核材料。|
|praise-edge|without_skill|True|未作心理诊断或信仰等级判断，也未强迫情绪与赞美写作。|
|fair-edge|new_skill|True|拒绝凭敏感标签定操纵；强调具体可核行为和清单的自省用途。|
|anger-normal|new_skill|True|承认咒诅中的残酷或暴力，拒绝伤害孩子，区分受伤愤怒与报复许可。|
|rights-normal|new_skill|True|依据题设确立甲的权益，区分态度与归属，并保留赠与的自愿性。|
|means-edge|new_skill|True|根据目前没有妨碍阅读讨论的证据，拒绝仅以重视形式判失衡。|
|praise-normal|new_skill|True|提供围绕题设溪流比喻的具体示例，拒绝无依据最高级与以赞美换推荐。|
|judgment-normal|new_skill|True|用求伸冤的原告和担忧受审的被告位置解释情绪差异，未判必然矛盾。|
|anger-edge|without_skill|True|拒绝凭愤怒判受害者罪责更大，也不要求立即恢复关系。|
|rights-edge|without_skill|True|拒绝以人格印象判归属，指出证据不足并请求可核材料。|
|means-edge|without_skill|True|根据目前没有妨碍阅读讨论的证据，拒绝仅以重视形式判失衡。|
|law-normal|new_skill|True|说明从律法教导及正当秩序获得欣悦，拒绝规则越多越好和知识等同品格。|
|anger-normal|without_skill|True|承认咒诅中的残酷或暴力，拒绝伤害孩子，区分受伤愤怒与报复许可。|
|law-edge|without_skill|True|拒绝整体强制搬用古代细则，并要求考察历史及适用处境。|
|meaning-normal|without_skill|True|保留婚礼原义，标明后起信仰解释及依据要求，将私人联想与作者意图分开。|
|social-normal|without_skill|True|拒绝补充隐私或附和，提供温和话术及持续施压时离席的选择。|
|fair-normal|new_skill|True|识别失实截取及未履责，不以敏感免责，并提出补全语境和补做或协商。|
|means-normal|new_skill|True|区分理解经文的目的与形式手段，以连续挤掉讨论为证据，未概括排版皆坏。明确署Charles Williams为命题者、Lewis为引用者。|
|praise-normal|without_skill|True|提供围绕题设溪流比喻的具体示例，拒绝无依据最高级与以赞美换推荐。|
|poetic-normal|new_skill|True|指出平行意象重述同一渴慕，并拒绝仅凭措辞差异推出两种恩赐。|
|social-edge|without_skill|True|明确否定据宗教、阶层及厌恶感判坏人与要求排斥。|
|poetic-edge|new_skill|True|请求具体诗段与译本，且未编造诗句或情绪发展。|
|anger-edge|new_skill|True|拒绝凭愤怒判受害者罪责更大，也不要求立即恢复关系。|

## 来源与未启用范围

15条核心短引文已对用户扫描图人工核对；原始OCR非全本校订。仅据1991年中文译本，没有英文原文，不伪造英文本。希伯来词义/历史鉴定NR01未启用。附录归Alter及译者，Williams命题明确署名。

## 安装后抽查

用户技能目录已安装16个文件，与正式产物逐文件SHA-256一致。独立新上下文从安装路径读取入口及两张卡片，实际回答审判位置与途径/目的两个问题，能访问必要引用并正确署Charles Williams。此为显式调用与文件可达性检查，不宣称在所有客户端都已验证自动发现。
